from server.models import User
from server import db
import bcrypt


def create_custom_account(username, email, password, pin, balance):
    new_user = User(username, email, bcrypt.hashpw(password.encode(), bcrypt.gensalt()), bcrypt.hashpw(pin.encode(), bcrypt.gensalt()), balance=balance)
    db.session.add(new_user)
    db.session.commit()


db.create_all()
create_custom_account('*EXCHANGE', '*', 'exchange', '0000', 1_000_000)

