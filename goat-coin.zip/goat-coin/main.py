from server import app, db #, socketio


if __name__ == '__main__':
    # db.create_all()
    # socketio.run(app)
    app.run()