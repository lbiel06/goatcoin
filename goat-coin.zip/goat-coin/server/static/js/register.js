$(() => {
    const validator = $("form").validate({
        rules: {
            username: {
                required: true,
                // pattern: /^[a-zA-Z0-9_]*$/,
                minlength: 4,
                maxlength: 20
    
            },
            email: {
                required: true,
                pattern: /\S+@\S+\.\S+/,
                maxlength: 100
            },
            password: {
                required: true,
                minlength: 4,
                maxlength: 20
            },
            password2: {
                equalTo: "#password"
            },
            pin: {
                required: true,
                minlength: 4,
                maxlength: 4,
            },
            pin2: {
                equalTo: "#pin"
            },
            // key: {
            //     required: true
            // }
        },
        messages: {
            username: {
                required: "This field is required.",
                minlength: "Username is too short.",
                maxlength: "Username is too long",
                pattern: "Username can contain only letters, digits and underscores."
            },
            email: {
                required: "This field is required.",
                pattern: "Invalid email adress.",
                maxlength: "Email adress is too long"
            },
            password: {
                required: "This field is required.",
                minlength: "Password is too short.",
                maxlength: "Password is too long",
            },
            password2: {
                equalTo: "Passwords must match."
            },
            pin: {
                required: "This field is required.",
                minlength: "PIN code must be 4 characters long.",
                maxlength: "PIN code must be 4 characters long.",
            },
            pin2: {
                equalTo: "PIN codes must match."
            },
            // key: {
            //     required: "This field is required."
            // }
        },
        submitHandler: (form, event) => {
            event.preventDefault();
            $.post("/register", data=$("form").serialize(), success=(response) => {
                    console.log(response)
                    errors = {}
                    if (response === "username-taken") {
                        errors["username"] = "Username is taken."
                    }
                    if (response === "email-taken") {
                        errors["email"] = "Email adress is taken."
                    }
                    // if (response === "invalid-key") {
                    //     errors["key"] = "Invalid key."
                    // }
                    if (response === "ok") {
                        window.location.replace('/login')
                    }
                    validator.showErrors(errors)
                }
            )
        }
    })
})
