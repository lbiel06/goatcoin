$(() => {
    const validator = $("form").validate({
        rules: {
            username: {
                required: true
            },
            password: {
                required: true
            }
        },
        messages: {
            username: {
                required: "This field is required."
            },
            password: {
                required: "This field is required."
            }
        },
        submitHandler: (form, event) => {
            event.preventDefault();
            $.post("/login", data=$("form").serialize(), success=(response) => {
                    console.log(response)
                    errors = {}
                    if (response === "invalid-username") {
                        errors["username"] = "Invalid username."
                    }
                    if (response === "invalid-password") {
                        errors["password"] = "Invalid password."
                    }
                    if (response === "ok") {
                        window.location.replace('/')
                    }
                    validator.showErrors(errors)
                }
            )
        }
    })
})