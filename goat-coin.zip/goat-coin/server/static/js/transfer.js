$(() => {
    const validator = $("form").validate({
        rules: {
            to: {
                required: true
            },
            ammount: {
                required: true,
                min: 1
            },
            pin: {
                required: true,
                minlength: 4,
                maxlength: 4,
                digits: true
            }
        },
        messages: {
            to: {
                required: "This field is required."
            },
            ammount: {
                min: "Nice try.",
                required: "This field is required."
            },
            pin: {
                required: "This field is required.",
                minlength: "Please enter a valid PIN code.",
                maxlength: "Please enter a valid PIN code.",
                digits: "Please enter a valid PIN code."
            }
        },
        submitHandler: (_, event) => {
            event.preventDefault();
            $.post("/transfer", data=$("form").serialize(), success=(response) => {
                    console.log(response)
                    errors = {}
                    if (response === "invalid-username") {
                        errors["username"] = "Invalid username."
                    }
                    if (response === "not-enough-funds") {
                        errors["ammount"] = "Not enough funds."
                    }
                    if (response === "invalid-pin") {
                        errors["pin"] = "Invalid PIN code."
                    }
                    if (response === "ok") {
                        window.location.replace('/')
                    }
                    validator.showErrors(errors)
                }
            )
        }
    })
})