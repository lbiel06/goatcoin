from flask import session
from server import db
from server.models import User
import bcrypt


def create_custom_account(username, email, password, pin, balance):
    new_user = User(username, email, bcrypt.hashpw(password.encode(), bcrypt.gensalt()), bcrypt.hashpw(pin.encode(), bcrypt.gensalt()), balance=balance)
    db.session.add(new_user)
    db.session.commit()


def is_authenticated():
    return 'username' in session


def get_username():
    return session['username']


def login_user(username):
    session['username'] = username


def logout_user():
    session.pop('username')
