from server import app, db
from server.models import *
from server.utils import *
from flask import render_template, redirect, url_for, request, session
from sqlalchemy import or_
import os
import bcrypt
import string


# def create_custom_account(username, email, password, pin, balance):
#     new_user = User(username, email, bcrypt.hashpw(password.encode(), bcrypt.gensalt()), bcrypt.hashpw(pin.encode(), bcrypt.gensalt()), balance=balance)
#     db.session.add(new_user)
#     db.session.commit()


# Create exchange account
# db.create_all()
# create_custom_account('*EXCHANGE', '*', 'storage', '0000', 1_000_000)



@app.template_filter('format_date')
def format_date(date):
    return date.strftime('%d.%m.%y %H:%M')
    

@app.route('/')
def home_view():
    if is_authenticated():
        this_user = User.query.get(get_username())
        transfers = db.session.query(Transfer).filter(or_(
            Transfer.from_==this_user.username,
            Transfer.to==this_user.username)).order_by(Transfer.date).all()
        return render_template('home.html', user=this_user, transfers=transfers)
    return redirect(url_for('login_view'))


@app.route('/transfer', methods=['GET', 'POST'])
def transfer_view():
    if request.method == 'GET':
        users = User.query.order_by(User.username).all()
        return render_template('transfer.html', users=users)
    else:
        username = request.form.get('to')
        ammount = request.form.get('ammount')
        pin = request.form.get('pin')
        
        if not all([username, ammount, pin]):
            return 'error'
        
        if not ammount.isdigit():
            return 'error'
        
        ammount = int(ammount)
        
        if not ammount > 0:
            return 'error'
        
        if not (user := User.query.get(username)):
            return 'invalid-username'

        this_user = User.query.get(get_username())
        
        if not this_user.balance >= ammount:
            return 'not-enough-funds'
        
        if not bcrypt.checkpw(pin.encode(), this_user.pin):
            return 'invalid-pin'
        
        this_user.balance -= ammount
        user.balance += ammount
        
        new_transfer = Transfer(this_user.username, username, ammount)
        db.session.add(new_transfer)
        db.session.commit()
        print(new_transfer)
        return 'ok'


@app.route('/login', methods=['GET', 'POST'])
def login_view():
    if request.method == 'GET':
        return render_template('login.html')
    else:
        username = request.form.get('username')
        password = request.form.get('password')
        
        if not all([username, password]):
            return 'error'
        
        if not (user := User.query.get(username)):
            return 'invalid-username'
        
        if not bcrypt.checkpw(password.encode(), user.password):
            print('password')
            return 'invalid-password'
        
        login_user(username)
        return 'ok'
        

@app.route('/register', methods=['GET', 'POST'])
def register_view():
    if request.method == 'GET':
        return render_template('register.html')
    
    else:
        username = request.form.get('username')
        email = request.form.get('email')
        password = request.form.get('password')
        pin = request.form.get('pin')
        # key = request.form.get('key')

        if not all([username, email, password, pin]):
            return 'error'
        if not 4 <= len(username) <= 20:
            return 'error'
        if not 4 <= len(password) <= 20:
            return 'error'
        if not all([x in string.ascii_letters + string.digits + '_' for x in username]):
            return "error"
        if not len(pin) == 4 or not pin.isdigit():
            return 'error'
            
        if User.query.get(username):
            return 'username-taken'
        
        if User.query.filter_by(email=email).all():
            return 'email-taken'
        
        # if not validate_access_key(email, key):
        #     return 'invalid-key'
        
        password_hash = bcrypt.hashpw(password.encode(), bcrypt.gensalt())
        pin_hash = bcrypt.hashpw(pin.encode(), bcrypt.gensalt())
        new_user = User(username, email, password_hash, pin_hash)
        db.session.add(new_user)
        db.session.commit()
        
        return 'ok'
    
    
@app.route('/all')
def all_transfers_view():
    transfers = Transfer.query.order_by(Transfer.date).all()
    return render_template('all.html', transfers=transfers)


@app.route('/users')
def all_users_view():
    users = User.query.order_by(User.username).all()
    return render_template('users.html', users=users)


@app.route('/logout')
def logout():
    if is_authenticated():
        logout_user()
    return redirect(url_for('login_view'))
