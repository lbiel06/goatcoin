import datetime
from server import db
from sqlalchemy.orm import Query


class User(db.Model):
    # type hint
    query: Query
    
    username = db.Column(db.String, primary_key=True)
    email = db.Column(db.String)
    password = db.Column(db.String)
    pin = db.Column(db.String)
    balance = db.Column(db.Integer)
    admin = db.Column(db.Boolean)
    
    def __init__(self, username, email, password, pin, admin=False, balance=0) -> None:
        self.username = username
        self.email = email
        self.password = password
        self.pin = pin
        self.balance = balance
        self.admin = admin

    def __repr__(self) -> str:
        return f'<user username={self.username}, email={self.email}, hash={self.password}>'
    

class Transfer(db.Model):
    query: Query
    
    tid = db.Column(db.Integer, primary_key=True, autoincrement=True)
    from_ = db.Column(db.String)
    to = db.Column(db.String)
    ammount = db.Column(db.Integer)
    date = db.Column(db.DateTime())
    
    def __init__(self, from_, to, ammount) -> None:
        self.from_ = from_
        self.to = to
        self.ammount = ammount
        self.date = datetime.datetime.now()

    def __repr__(self) -> str:
        return f'<transfer id={self.tid}, from {self.from_}, to {self.to}, ammount={self.ammount}, date={self.date}'

